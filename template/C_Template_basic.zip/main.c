#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main() {



	return 0;
}